# Mini Project
# ติดตั้ง
pip install pip install -r install.txt

# เข้าไปในโปรเจกต์
cd myproject

# รันmysql
mysqld --console

# รันtailwind
python manage.py tailwind start

# makemigrations
python manage.py makemigrations
python manage.py migrate

python manage.py runserver